<?php
$current = new DateTime();
$result = $current->add(new DateInterval('P1M'));
